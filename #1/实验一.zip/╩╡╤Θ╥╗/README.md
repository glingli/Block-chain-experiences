# 区块链中的密码学

## 实验介绍

这次实验通过调用已有的加密算法库Crypto，练习Hash算法，椭圆曲线ECDH算法的使用。在 VS Code中创建项目和 js 文件，编写代码实现并成功调试。

## 能学习到什么

- Hash的使用方法
- 区块的结构
- 椭圆曲线ECDH的使用方法
- 随机数（伪随机）的生成方法
- Node.js的使用方法
- JavaScript脚本语言
- Crypto库的使用方法

## 环境准备

- 安装[Visual Studio Code](https://code.visualstudio.com/)或者其它IDE工具。用于查看，编辑，调试

- 安装[Node.js](https://nodejs.org/zh-cn/)和[npm](https://www.npmjs.com/)，安装Node.js时，会自动安装npm。用于运行代码

  - [Node.js v8.x 中文文档](https://www.nodeapp.cn/)
  - [Node.js 官方文档](https://nodejs.org/zh-cn/)
  - [npm 中文文档](https://www.npmjs.cn/)

- 安装依赖

  crypto，用于生成SHA256 Hash值。crypto是node.js自带的库，不需要另外安装。


## 知识准备

- 学习VS Code

  [Visual Studio Code](https://code.visualstudio.com/) Code editing.学习创建workspace，创建Folder，创建File，在workspace中导入Folder，学习如何Debug代码，如何使用console。
  
- 学习Javascript

  [README.md](../README.md)

- 学习Node.js

  [README.md](../README.md)

- 学习crypto

  The [crypto](https://nodejs.org/dist/latest-v12.x/docs/api/crypto.html) module provides cryptographic functionality that includes a set of wrappers for OpenSSL's hash, HMAC, cipher, decipher, sign, and verify functions.

## 实验步骤

### 第一步: 给字符串取Hash

给自己的名字取hash值并打印，要求使用sha256算法。下面是一个示例，也可以通过读[crypto_class_hash](https://nodejs.org/dist/latest-v12.x/docs/api/crypto.html#crypto_class_hash)文档获取其它方法。

Example: Using `Hash` objects as streams:

```
const crypto = require('crypto');
const hash = crypto.createHash('sha1');

hash.on('readable', () => {
  // Only one element is going to be produced by the
  // hash stream.
  const data = hash.read();
  if (data) {
    console.log(data.toString('hex'));
  }
});

hash.write('some data to hash');
hash.end();
```

### 第二步: 给区块取Hash

编写Block，数据模型见[Block data model](Block-data-model.md)，其中body属性使用自己的名字。给Block取Hash值并打印，要求使用sha256。

编写Block参考下面定义：

```
class Block {
  constructor(your name) {
  	...
    this.body = your name,
    ...
  }
}
```

给Block取hash参考下面代码。也可以通过读[crypto_class_hash](https://nodejs.org/dist/latest-v12.x/docs/api/crypto.html#crypto_class_hash)文档获取其它求Hash的方法。

```
const crypto = require('crypto');
const hash = crypto.createHash('sha1');

hash.on('readable', () => {
  // Only one element is going to be produced by the
  // hash stream.
  const data = hash.read();
  if (data) {
    console.log(data.toString('hex'));
  }
});

hash.write(JSON.stringify(new block);
hash.end();
```

### 第三步: 生成随机数

- 抛硬币方式

  抛256次硬币，记录结果。了解一下就可以了。

- 离线网页方式

  请求网页 [bitaddress](https://www.bitaddress.org)，请求成功之后，把网页另存为本地页面，断网操作。

- 调用Crypto库生成

  生成一个256位的随机数，注意是256位哦。

  ```
  const crypto = require('crypto');
  crypto.randomBytes(128, (err, buf) => {
    if (err) throw err;
    console.log(`${buf.length} bytes of random data: ${buf.toString('hex')}`);
  });
  ```

### 第四步: 生成椭圆曲线ECDH公私钥对

生成公私钥对并打印，要求打印结果是 “hex” 编码（encoding），“compressed” 格式（format）。下面的代码有缺憾，需要参考 [crypto_class_ecdh](https://nodejs.org/dist/latest-v12.x/docs/api/crypto.html#crypto_class_ecdh) 完成内容。

```
const crypto = require('crypto');

const bob = crypto.createECDH('secp256k1');

// Bob uses a newly generated cryptographically strong
// pseudorandom key pair
bob.generateKeys();
```

