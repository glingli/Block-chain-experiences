Block data model

```
{
    "hash" : "",
    "height" : 0,
    "body": [],
    "time": 0,
    previousblockhash: ""

}
```

