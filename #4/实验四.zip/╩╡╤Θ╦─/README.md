# FISCO-BCOS联盟链搭建及学习

## 实验介绍

通过这次实验了解国内优秀的联盟链架构FISCO-BCOS平台，理解BCOS平台的配置及运行机制，掌握BCOS平台的环境配置和搭建流程，尝试在搭建好的本地BCOS平台上进行控制台操作。

## 能学习到什么

- 了解Ubuntu系统及linux命令行的基本知识，VMware虚拟机管理软件的使用
- 学习Ubuntu系统在虚拟机管理软件下的安装和配置，linux系统的使用与命令行操作
- 了解FISCO-BCOS的基本知识，新版本2.0的基本特性
- 学习Ubuntu系统上java环境的配置
- 学习在Ubuntu系统中BCOS平台的搭建流程
- 学习在本地运行的BCOS上控制台的一些基础操作
- 学习BCOS区块链浏览器的搭建过程

## 环境准备

- 安装VMware或者其它虚拟机管理软件，用于创建和管理不同操作系统的虚拟机。

    - [VMware Workstation Pro](https://my.vmware.com/cn/web/vmware/info/slug/desktop_end_user_computing/vmware_workstation_pro/15_0)

- 在VMware等虚拟机管理软件安装Ubuntu16.04版本的虚拟机镜像，安装时，新手最好安装带桌面的，便于学习Ubuntu系统的使用，可以学习一些简单的linux命令行操作。记住创建镜像时设置的root密码，Ubuntu系统中命令行使用root权限比较频繁。

  - [Ubuntu 16 releases](http://releases.ubuntu.com/16.04.6/)
  - [Ubuntu BitTorrent](https://ubuntu.com/download/alternative-downloads?_ga=2.32750583.811944566.1572175906-1355295711.1569210277)
  
  - [Linux命令行大全中文文档](https://man.linuxde.net/)
  
- 安装java依赖

  - 安装oracle的1.8版本以上的jdk，用来运行BCOS的一键搭链脚本

  - 首先查询本机是否有自带的openjdk，有的话先将其卸载再安装oracle的jdk

    ```
    打开cmd
    $ sudo apt-get remove openjdk*
    ```

- 安装jdk，并配置环境变量
  
    - 打开cmd，创建/usr/java目录，将java安装包移动到该目录下，进入该目录并解压
    
        ```
        $ mkdir /usr/java
        
        #将java1.8的安装包移动到安装目录下,此处在安装包所在路径下
        $ mv jdk-8u181-linux-x64.tar.gz(此处根据自己的安装包文件名填写) /usr/java/
        $ cd /usr/java
        
        #解压文件到当前目录
        $ tar -zxf jdk-8u181-linux-x64.tar.gz
        ```
      
        
      
  - 添加java路径到环境变量，同时添加至用户和全局（可选）下。分别编辑这两个文件，在这两个文件中添加如下路径信息(注：按i进入编辑模式，Esc退出编辑模式，再输入:wq强制保存并退出)
  
      ```
      $ vi ~/.bashrc
      $ vi /etc/profile
      
      #先后到两个文件最末尾，按i键进入插入编辑模式，添加如下路径(即java的安装路径和某些包路径)
      JAVA_HOME=/usr/java/jdk1.8.0_181
      JRE_HOME=$JAVA_HOME/jre
      PATH=$PATH:JAVA_HOME/bin:$JRE_HOME/bin
      CLASSPATH=:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:JRE_HOME/lib/dt.jar
      export JAVA_HOME JRE_HOME PATH CLASSPATH
      
      #安装完成后查看版本信息，出现对应java1.8信息即成功
      $ java -version
      ​```
      ```
  

## 脚本一键搭链

- 安装依赖及创建操作目录

  ```
  $ sudo apt install -y openssl curl
  
  $ cd ~ && mkdir -p fisco && cd fisco
  ```

- 获取搭链脚本，两种方法，第一种不行就使用第二种

  - 从网络中获取脚本并赋予执行权限

    ```
    $ curl -LO https://raw.githubusercontent.com/FISCO-BCOS/FISCO-BCOS/master/tools/build_chain.sh && chmod u+x build_chain.sh
    ```

    

  - 本地创建，内容为 [搭链脚本 build_chain.sh](https://github.com/FISCO-BCOS/FISCO-BCOS/blob/master/tools/build_chain.sh)

    ```
    $ vim build_chain.sh
    $ chmod a+x build_chain.sh
    ```

- 搭建单群组4节点联盟链，确保30300~30303，20200~20203，8545~8548端口未被占用

  ```
  $ bash build_chain.sh -l "127.0.0.1:4" -p 30300,20200,8545
  ```

  命令执行成功会输出`All completed`。如果执行出错，请检查`nodes/build.log`文件中的错误信息。

- 启动FISCO-BCOS链

  启动所有节点

  ```
  $ bash nodes/127.0.0.1/start_all.sh
  ```

  启动成功会输出相关信息，如果失败，检查一下是否相关端口已经被占用

  ```
  #检查进程是否启动
  $ ps -ef | grep -v grep | fisco-bcos
  #检查8080端口占用情况
  $ netstat -ap | grep 8080
  
  $ kill -9 件进程PID
  ```

- 检查日志输出

  查看节点链接的节点数

  ```
  $ tail -f nodes/127.0.0.1/node0/log/log* | grep connected
  ```

  检查共识状态，正常情况会不停输出`++++Generating seal`

  ```
  $ tail -f nodes/127.0.0.1/node0/log/log* | grep ++++
  ```


## 配置及控制台使用

- 搭建控制台，

  - 从网络上获取脚本并允许

    ```
    $ bash <(curl -s https://raw.githubusercontent.com/FISCO-BCOS/console/master/tools/download_console.sh)
    ```
    
    
    
  - 在fisco目录下创建 ，内容为[控制台脚本 download_console.sh](https://github.com/FISCO-BCOS/console/blob/master/tools/download_console.sh)

    ```
    #在本地编辑一个download_console.sh文件，然后加权限执行
    $ vim download_console.sh
    $ chmod a+x download_console.sh
    $ bash download_console.sh
    ```

- 拷贝控制台配置文件

  ```
  $ cp -n console/conf/applicationContext-sample.xml console/conf/applicationContext.xml
  ```

- 配置控制台证书

  ```
  $ cp nodes/127.0.0.1/sdk/* console/conf/
  ```

- 启动控制台

  ```
  $ cd console && bash start.sh
  ```


## BCOS浏览器搭建环境配置

- python环境检测及requests和mysql-python安装

  ```
  $ python -V
  $ curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
  $ sudo python get-pip.py
  
  #requests安装
  $ sudo pip install requests
  
  #mysql-python安装
  $ sudo apt-get install libmysqlclient-dev -y
  $ sudo apt-get install python-dev -y
  $ sudo pip install MySQL-python
  ```

- 安装mysql并配置

  ```
  $ sudo apt-get install -y mysql*
  
  #安装过程中给root用户配置密码，成功后启动mysql
  $ sudo service mysql start
  
  #用root账户登录
  $ sudo mysql -u root -p
  
  #给root授权远程访问，创建db_browser数据库
  > GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '123456' WITH GRANT OPTION;
  > create database db_browser;
  ```

- 获取浏览器源码，进入相关目录修改配置文件

  ```
  $ git clone https://github.com/FISCO-BCOS/fisco-bcos-browser.git
  
  $ cd fisco-bcos-browser/deploy
  
  $ vim common.properties
  ```

  ![](.\images\bcos浏览器配置文件.png)

  注：user修改为root，password修改为自己的密码，database修改为db_browser。

- 部署浏览器

  ```
  #此时在fisco-bcos-browser/deploy目录下
  #开启，访问127.0.0.1:5100端口查看
  $ python deploy.py startAll
  
  #关闭
  $ python deploy.py stopAll
  ```


## 实验步骤

### 第一步: 在本地搭建FISCO-BCOS链

1. 安装Ubuntu16.04版本虚拟机并安装java环境；
2. 使用搭链脚本在本地搭链；
3. 启动本地的BCOS链；
4. 提交搭链成功的截图

### 第二步: 学习BCOS控制台使用方法

1. 为本地的BCOS链配置控制台；
2. 使用控制台查询当前BCOS版本相关信息、区块高度、共识节点信息等，具体可参考[控制台操作手册](https://fisco-bcos-documentation.readthedocs.io/zh_CN/release-2.0/docs/manual/console.html)；
3. 使用控制台部署HelloWorld合约并调用，查看区块高度变化；
4. 提交控制台配置成功的截图、通过控制台获取BCOS信息的截图

### 第三步:在本地搭建一个区块链浏览器

1. 首先检查python是否在2.7版本及以上，然后安装新版本的pip，使用pip安装requests和mysql-python依赖；
2. 在本地安装并配置mysql；
3. 拉取区块链浏览器源码并使用脚本运行，可以参考[BCOS区块链浏览器搭建](https://fisco-bcos-documentation.readthedocs.io/zh_CN/latest/docs/browser/deploy.html)；
4. 提交区块链浏览器截图