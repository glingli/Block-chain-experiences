const bitcoin = require('bitcoinjs-lib');
const bitcoinMessage = require('bitcoinjs-message');

const aliceAddress = "";
const alicePrivateKey = "";

const bobAddress = "";
const bobPrivateKey = "";

class Transaction {
  constructor() {
    this.from = "";
    this.to = "";
    this.value = 0;
    this.unit = "BTC";
    this.time = 0;
    this.signature = "";
  }
}

// Alice send a request to transfer coin to bob
function aliceTransferToBob() {
  let tx = new Transaction();
  tx.from = aliceAddress;
  tx.to = bobAddress;
  // tx.value = 
  // tx.time = 
  tx.signature = bitcoinMessage.sign(JSON.stringify(tx), alicePrivateKey, keyPair.compressed).toString('base64')
  return tx;
}

// Alice send a request to transfer coin to bob
function bobTransferToBob() {
  // Write your code here
}

// Miner verify a transaction
function minerVerifyTransaction(tx) {
  // let message = 
  // let address = 
  // let signature = 
  // tx.signature = 
  console.log('result', bitcoinMessage.verify(message, address, signature));
}
