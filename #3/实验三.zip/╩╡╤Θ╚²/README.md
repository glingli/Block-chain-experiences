# 区块链上的用户身份

## 实验介绍

通过这次实验了解区块链网络上用户的身份，理解将公钥体系作为链上身份的机制，掌握为一笔交易签名、验签的方法，尝试在模拟区块链网络上不同身份的用户间转账。

## 能学习到什么

- 了解区块链钱包的基本知识，公钥、私钥和地址
- 学习比特币钱包 Electrum，体会通过 seed 生成公私钥对
- 了解以太坊开发工具 Ganache
- 学习以太坊插件钱包 MetaMask，如何用 MetaMask 完成转账
- 学习验证一个消息签名
- 学习为一笔交易签名，并验证

## 环境准备

- 安装[Visual Studio Code](https://code.visualstudio.com/)或者其它IDE工具。用于查看，编辑，调试

- 安装[Node.js](https://nodejs.org/zh-cn/)和[npm](https://www.npmjs.com/)，安装Node.js时，会自动安装npm。用于运行代码

  - [Node.js v8.x 中文文档](https://www.nodeapp.cn/)
  - [Node.js 官方文档](https://nodejs.org/zh-cn/)
  - [npm 中文文档](https://www.npmjs.cn/)

- 安装依赖

  - 安装bitcoinjs-lib，比特币工具，用来导入私钥

    ```
    打开cmd
    cd 到代码根目录
    npm i bitcoinjs-lib
    ```

- 安装bitcoinjs-message，比特币工具，用来签名、验签

    ```
    打开cmd
    cd 到代码根目录
    npm i bitcoinjs-message
    ```

- 安装 [Electrum](https://electrum.org/#download)

  - Windows 系统安装 [Windows Installer](https://download.electrum.org/3.3.8/electrum-3.3.8-setup.exe) 版本，按照提示进行安装，种子类型选择**老式地址**，如下图所示，其它选择默认选项即可

    ![sign-verify](/images/wallet-type.png)

  - [Electrum 源码](https://github.com/spesmilo/electrum)

- 安装 [Firefox ](https://www.firefox.com.cn/?utm_medium=referral&utm_source=mozilla.org) 浏览器，用于安装 MetaMask 插件。有条件的也可以安装 Chrome 浏览器
- 安装 [MetaMask](https://metamask.io/) Brings Ethereum to your browser
- 安装 [Ganache](https://www.trufflesuite.com/ganache) Quickly fire up a personal Ethereum blockchain which you can use to run tests, execute commands, and inspect state while controlling how the chain operates.

## 知识准备

- 学习 bitcoinjs-message 和 bitcoinjs-lib
  - [github](https://github.com/bitcoinjs/bitcoinjs-message)
  - [npmjs-bitcoinjs-message](https://www.npmjs.com/package/bitcoinjs-message)
  - [npmjs-bitcoinjs-lib](https://www.npmjs.com/package/bitcoinjs-lib)

签名代码

```
const bitcoinMessage = require('bitcoinjs-message');

const message = 'This is an example of a signed message.';
const signature = bitcoinMessage.sign(message, privateKey, keyPair.compressed).toString('base64')
```

验签代码

```
const bitcoinMessage = require('bitcoinjs-message');

const address = '13w3BBE4SmmM9fmZ4F6YvrD1d1tyZejxtu';
const message = 'This is an example of a signed message.';
// Signed by private key
const signature = 'H38sUprVylojWRVEMyagEUwu8ty3hfpAorTTI5kCILarNdYPXeOkZXBw/kobKdbyVWvDvxGW8hUAnQyrWwLaMNQ=';
console.log(bitcoinMessage.verify(message, address, signature));
```

导入私钥代码

```
const bitcoin = require('bitcoinjs-lib');

// WIF(Wallet Import Format)比特币钱包导入格式，通过 WIF 格式导入私钥
const keyPair = bitcoin.ECPair.fromWIF('L3GBmrf3Fr1z9ayVGESkkevZ5s2ANvyNH8Lcmma8hzwTRS2VWENK')
const privateKey = keyPair.privateKey
```

- 学习使用 Electrum 自带的工具为消息签名

  1. 安装好 Electrum  之后，第一次进入应用如下所示。

   ![sign-verify](/images/wallet-home.png)

2. 切换到地址视图，每一个地址对应一个私钥，代表一个账户。复制其中一个地址，如下所示。

     ![sign-verify](/images/wallet-address.png)

  3. 选择菜单，工具--签名/验证消息，弹出如下对话框。在签名对话框中粘贴复制的地址，填写消息内容，完成签名。

     ![sign-verify](/images/wallet-sign.png)

- 学习 Ganache。启动Ganache在本地模拟以太坊网络，用于开发调试。

  安装好 Ganache 之后，打开软件，在初始界面选择 QUICK START 进入应用。如下图所示。

  ![sign-verify](/images/ganache.png)

  上面截图中的 MNEMONIC 是公私钥、地址的助记符，作用类似于 Electrum 中的 seed ，向 MetaMask 钱包中导入账户时用。Ganache 启动之后默认生成10个账户，每一个账户有100 ETH（以太币）。

- 学习 MetaMask。MetaMask 是一个以太坊插件钱包，作为浏览器插件安装。安装好之后，如下图所示。

  将 MetaMask 连入 Ganache 服务。然后选择“从助记词还原”，导入 Ganache 中的 MNEMONIC。

  ![sign-verify](/images/metamask.png)

- 钱包知识，扩展阅读。了解下面几种钱包类型，尝试判断 Electrum 是其中哪一种？

  **Non-deterministic Wallet**: (random wallets) A wallet where private keys are generated from random numbers.

  **Deterministic Wallet**: A wallet where addresses, private keys, and public keys can be traced back to their original seed words.

  **Hierarchical Deterministic Wallet**: An advanced type of deterministic wallet that contains keys derived in a tree structure.

  **非确定性钱包**（nondeterministic wallet）：每个密钥都是从随机数独立生成，密钥彼此之间无关联，这种钱包也被称为“Just a Bunch Of Keys（一堆密钥）”，简称JBOK钱包。

  **确定性钱包（deterministic wallet）**：所有密钥都是从一个主密钥派生出来，这个密钥即为种子（Seed）。该类型钱包中所有密钥都相互关联，通过原始种子可以找到所有密钥。确定性钱包中使用了很多不同的密钥推导方法，最常用的是使用树状结构，称为分级确定性钱包或者HD (hierarchical deterministic)钱包。

  | Wallet Type                   | Non-Deterministic Wallet                 | Sequential Deterministic Wallet          | Hierarchical Deterministic Wallet        |
  | ----------------------------- | ---------------------------------------- | ---------------------------------------- | ---------------------------------------- |
  | Description                   | These wallets are simply collections of randomly generated private keys. | These wallets contain private keys that are derived sequentially from a single seed and can be traced back to that seed. | These wallets contain keys derived in a tree structure, such that a parent key derives children keys, children keys derive grandchildren keys and so on to an infinite depth. |
  | How to get a new private key? | Private key = randomly generated between 1 and 2 ^256 | Private key = sha256(seed + n)， where seed = 128 purely random bits | Private key = sha256(address(publicKey(seed) + n)) |

## 实验步骤

### 第一步: 对消息签名并验签

1. 在 Electrum 中随机选择一个账户，对自己的姓名进行签名，拿到签名结果
2. 调用 "bitcoinjs-message" js库，以编码方式完成签名验证
3. 将“bitcoinjs” 文件夹导入 VS Code，完成 message.js

### 第二步: 对交易签名并验签

1. 在 Electrum 中随机选择两个账户，拿到私钥和地址，分别作为 Alice 和 Bob 的账户（注意：真实场景中，一个 seed 生成的多个账户只用于同一个人）
2. 定义一笔交易，Alice 向 Bob 转1个币，Alice 发起转账请求，矿工验证交易
3. Bob向自己转1个币，Bob发起转账请求，矿工验证交易
4. 将“bitcoinjs” 文件夹导入 VS Code，完成 transaction.js

### 第三步: 在以太坊模拟网络上转账

1. 启动 Ganache，配置 RPC server 监听的端口
2. 打开 MetaMask，接入 Ganache 服务
3. 将 Ganache 中的 MNEMONIC 导入 MetaMask
4. 在两个账户之间转账，转账额度为自己学号后两位数字

